#!/bin/bash
bash ../icecube.sh example_icestick.v
